<x-app-public title="Convert Pulsa ke E-Wallet">
    <section class="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
        <nav class="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
            <a href="/" class="text-xl font-black">Pulsa<span class="text-cyan-300">Cash</span></a>
            <div class="hidden gap-6 md:flex text-sm text-slate-200">
                <a href="#rate">Rate</a>
                <a href="#cara-kerja">Cara Kerja</a>
                <a href="#faq">FAQ</a>
                <a href="#kontak">Kontak</a>
            </div>
            <a href="{{ route('orders.create') }}" class="rounded-full bg-cyan-400 px-5 py-2 font-semibold text-slate-950">Convert Pulsa</a>
        </nav>

        <div class="mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-2 md:items-center">
            <div>
                <p class="mb-4 inline-flex rounded-full bg-white/10 px-4 py-2 text-sm text-cyan-100">Proses manual, aman, dan transparan</p>
                <h1 class="text-4xl font-black leading-tight md:text-6xl">Convert pulsa jadi saldo e-wallet atau transfer bank.</h1>
                <p class="mt-6 text-lg text-slate-300">Pilih provider, masukkan nominal, lihat estimasi pencairan, lalu lanjutkan transaksi via WhatsApp admin.</p>
                <div class="mt-8 flex flex-wrap gap-3">
                    <a href="{{ route('orders.create') }}" class="rounded-xl bg-cyan-400 px-6 py-3 font-bold text-slate-950">Convert Sekarang</a>
                    <a href="#rate" class="rounded-xl border border-white/20 px-6 py-3 font-bold">Lihat Rate</a>
                </div>
                <div class="mt-8 grid grid-cols-3 gap-3 text-center">
                    <div class="rounded-2xl bg-white/10 p-4"><b>1-15</b><br><span class="text-sm text-slate-300">Menit</span></div>
                    <div class="rounded-2xl bg-white/10 p-4"><b>{{ $rates->count() }}+</b><br><span class="text-sm text-slate-300">Provider</span></div>
                    <div class="rounded-2xl bg-white/10 p-4"><b>24/7</b><br><span class="text-sm text-slate-300">CS</span></div>
                </div>
            </div>

            <div class="rounded-3xl border border-white/10 bg-white/10 p-6 shadow-2xl">
                <h2 class="text-2xl font-bold">Kalkulator Estimasi</h2>
                <p class="mt-2 text-slate-300">Hitung nominal yang akan diterima.</p>
                <div class="mt-6 space-y-4">
                    <select id="provider" class="w-full rounded-xl border-0 bg-white p-3 text-slate-900">
                        @foreach($rates as $rate)
                            <option value="{{ $rate->rate }}">{{ $rate->provider }} - {{ $rate->rate }}</option>
                        @endforeach
                    </select>
                    <input id="amount" type="number" class="w-full rounded-xl border-0 bg-white p-3 text-slate-900" placeholder="Nominal pulsa, contoh 100000">
                    <div class="rounded-2xl bg-slate-950/70 p-5">
                        <p class="text-sm text-slate-300">Estimasi diterima</p>
                        <p id="result" class="text-3xl font-black text-cyan-300">Rp0</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="rate" class="bg-white px-6 py-20 text-slate-900">
        <div class="mx-auto max-w-6xl">
            <h2 class="text-3xl font-black">Rate Convert Pulsa</h2>
            <p class="mt-2 text-slate-600">Rate dapat berubah sewaktu-waktu. Hubungi admin untuk konfirmasi akhir.</p>
            <div class="mt-8 grid gap-4 md:grid-cols-3">
                @foreach($rates as $rate)
                    <div class="rounded-2xl border p-6 shadow-sm">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xl font-bold">{{ $rate->provider }}</h3>
                            <span class="rounded-full bg-cyan-100 px-3 py-1 font-bold text-cyan-700">{{ $rate->rate }}</span>
                        </div>
                        <p class="mt-4 text-sm text-slate-600">Minimal Rp{{ number_format($rate->min_amount,0,',','.') }}</p>
                        <p class="text-sm text-slate-600">Maksimal Rp{{ number_format($rate->max_amount,0,',','.') }}</p>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <section id="cara-kerja" class="bg-slate-50 px-6 py-20 text-slate-900">
        <div class="mx-auto max-w-6xl">
            <h2 class="text-3xl font-black">Cara Kerja</h2>
            <div class="mt-8 grid gap-6 md:grid-cols-3">
                @foreach([['Isi Form','Pilih provider, nominal, dan tujuan pencairan.'],['Transfer Pulsa','Admin mengirim nomor tujuan dan instruksi transfer pulsa.'],['Terima Saldo','Setelah valid, saldo dikirim ke e-wallet/rekening.']] as $i => $step)
                    <div class="rounded-3xl bg-white p-7 shadow-sm">
                        <span class="grid h-12 w-12 place-items-center rounded-full bg-cyan-400 font-black">{{ $i+1 }}</span>
                        <h3 class="mt-5 text-xl font-bold">{{ $step[0] }}</h3>
                        <p class="mt-2 text-slate-600">{{ $step[1] }}</p>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <section id="faq" class="bg-white px-6 py-20 text-slate-900">
        <div class="mx-auto max-w-4xl">
            <h2 class="text-3xl font-black">FAQ</h2>
            <div class="mt-8 space-y-4">
                <details class="rounded-2xl border p-5"><summary class="font-bold">Bagaimana menghitung pencairan?</summary><p class="mt-3 text-slate-600">Nominal pulsa dikalikan rate provider. Contoh Rp100.000 x 0,80 = Rp80.000.</p></details>
                <details class="rounded-2xl border p-5"><summary class="font-bold">Apakah transaksi otomatis?</summary><p class="mt-3 text-slate-600">Contoh starter ini memakai validasi manual oleh admin agar lebih aman.</p></details>
                <details class="rounded-2xl border p-5"><summary class="font-bold">Apakah menerima pulsa ilegal?</summary><p class="mt-3 text-slate-600">Tidak. Tambahkan prosedur anti-fraud dan verifikasi sumber pulsa sebelum memproses order.</p></details>
            </div>
        </div>
    </section>

    <footer id="kontak" class="bg-slate-950 px-6 py-10 text-slate-300">
        <div class="mx-auto flex max-w-6xl flex-col justify-between gap-4 md:flex-row">
            <p><b class="text-white">PulsaCash</b><br>Website convert pulsa starter Laravel.</p>
            <a class="text-cyan-300" href="https://wa.me/{{ $whatsapp }}">Hubungi WhatsApp</a>
        </div>
    </footer>

    <script>
        const provider = document.getElementById('provider');
        const amount = document.getElementById('amount');
        const result = document.getElementById('result');

        function rupiah(n) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n || 0);
        }

        function calculate() {
            result.textContent = rupiah(Number(provider.value) * Number(amount.value));
        }

        provider.addEventListener('change', calculate);
        amount.addEventListener('input', calculate);
    </script>
</x-app-public>
