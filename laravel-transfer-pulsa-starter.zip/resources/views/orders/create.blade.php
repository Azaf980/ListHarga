<x-app-public title="Form Convert Pulsa">
    <section class="min-h-screen bg-slate-100 px-6 py-10 text-slate-900">
        <div class="mx-auto max-w-3xl rounded-3xl bg-white p-8 shadow-xl">
            <a href="/" class="text-sm text-cyan-700">← Kembali</a>
            <h1 class="mt-4 text-3xl font-black">Form Convert Pulsa</h1>
            <p class="mt-2 text-slate-600">Isi data dengan benar. Setelah submit, Anda akan diarahkan ke WhatsApp admin.</p>

            @if ($errors->any())
                <div class="mt-6 rounded-xl bg-red-50 p-4 text-red-700">
                    <ul class="list-disc pl-5">
                        @foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('orders.store') }}" class="mt-8 grid gap-5">
                @csrf
                <div class="grid gap-4 md:grid-cols-2">
                    <label>Nama
                        <input name="name" value="{{ old('name') }}" class="mt-1 w-full rounded-xl border p-3" required>
                    </label>
                    <label>No WhatsApp
                        <input name="phone" value="{{ old('phone') }}" class="mt-1 w-full rounded-xl border p-3" required>
                    </label>
                </div>

                <div class="grid gap-4 md:grid-cols-2">
                    <label>Provider
                        <select name="provider" class="mt-1 w-full rounded-xl border p-3" required>
                            @foreach($rates as $rate)
                                <option value="{{ $rate->provider }}" data-rate="{{ $rate->rate }}">{{ $rate->provider }} - rate {{ $rate->rate }}</option>
                            @endforeach
                        </select>
                    </label>
                    <label>Nominal Pulsa
                        <input name="amount" type="number" value="{{ old('amount') }}" class="mt-1 w-full rounded-xl border p-3" required>
                    </label>
                </div>

                <div class="grid gap-4 md:grid-cols-2">
                    <label>Metode Pencairan
                        <select name="payout_method" class="mt-1 w-full rounded-xl border p-3" required>
                            <option>DANA</option><option>OVO</option><option>GoPay</option><option>ShopeePay</option>
                            <option>BCA</option><option>BRI</option><option>BNI</option><option>Mandiri</option>
                        </select>
                    </label>
                    <label>Nomor Rekening/E-wallet
                        <input name="account_number" value="{{ old('account_number') }}" class="mt-1 w-full rounded-xl border p-3" required>
                    </label>
                </div>

                <label>Nama Pemilik Rekening/E-wallet
                    <input name="account_name" value="{{ old('account_name') }}" class="mt-1 w-full rounded-xl border p-3" required>
                </label>

                <label>Catatan
                    <textarea name="note" class="mt-1 w-full rounded-xl border p-3" rows="4">{{ old('note') }}</textarea>
                </label>

                <button class="rounded-xl bg-cyan-500 px-6 py-3 font-black text-slate-950">Lanjut ke WhatsApp</button>
            </form>
        </div>
    </section>
</x-app-public>
