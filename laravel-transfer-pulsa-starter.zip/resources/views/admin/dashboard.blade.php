<x-app-layout>
    <x-slot name="header"><h2 class="font-semibold text-xl">Dashboard Admin</h2></x-slot>
    <div class="p-6">
        <div class="grid gap-4 md:grid-cols-4">
            <div class="rounded bg-white p-5 shadow">Total Order<br><b class="text-2xl">{{ $totalOrders }}</b></div>
            <div class="rounded bg-white p-5 shadow">Pending<br><b class="text-2xl">{{ $pendingOrders }}</b></div>
            <div class="rounded bg-white p-5 shadow">Paid<br><b class="text-2xl">{{ $paidOrders }}</b></div>
            <div class="rounded bg-white p-5 shadow">Rate Aktif<br><b class="text-2xl">{{ $activeRates }}</b></div>
        </div>

        <div class="mt-8 rounded bg-white p-5 shadow">
            <h3 class="font-bold">Order Terbaru</h3>
            <table class="mt-4 w-full text-sm">
                <thead><tr class="border-b"><th class="py-2 text-left">Invoice</th><th>Provider</th><th>Nominal</th><th>Status</th></tr></thead>
                <tbody>
                    @foreach($latestOrders as $order)
                        <tr class="border-b"><td class="py-2">{{ $order->invoice }}</td><td>{{ $order->provider }}</td><td>Rp{{ number_format($order->amount,0,',','.') }}</td><td>{{ $order->status }}</td></tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</x-app-layout>
