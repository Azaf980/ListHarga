<x-app-layout>
    <x-slot name="header"><h2 class="font-semibold text-xl">Rate Provider</h2></x-slot>
    <div class="p-6">
        <a href="{{ route('admin.rates.create') }}" class="rounded bg-blue-600 px-4 py-2 text-white">Tambah Rate</a>
        @if(session('success'))<p class="mt-4 text-green-700">{{ session('success') }}</p>@endif
        <table class="mt-6 w-full rounded bg-white text-sm shadow">
            <thead><tr class="border-b"><th class="p-3 text-left">Provider</th><th>Rate</th><th>Min</th><th>Max</th><th>Aktif</th><th>Aksi</th></tr></thead>
            <tbody>
                @foreach($rates as $rate)
                    <tr class="border-b">
                        <td class="p-3">{{ $rate->provider }}</td>
                        <td>{{ $rate->rate }}</td>
                        <td>Rp{{ number_format($rate->min_amount,0,',','.') }}</td>
                        <td>Rp{{ number_format($rate->max_amount,0,',','.') }}</td>
                        <td>{{ $rate->is_active ? 'Ya' : 'Tidak' }}</td>
                        <td>
                            <a class="text-blue-600" href="{{ route('admin.rates.edit', $rate) }}">Edit</a>
                            <form class="inline" method="POST" action="{{ route('admin.rates.destroy', $rate) }}">
                                @csrf @method('DELETE')
                                <button class="ml-2 text-red-600" onclick="return confirm('Hapus rate?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</x-app-layout>
