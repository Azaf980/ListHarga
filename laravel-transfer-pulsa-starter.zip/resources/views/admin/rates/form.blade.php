<x-app-layout>
    <x-slot name="header"><h2 class="font-semibold text-xl">{{ $rate->exists ? 'Edit' : 'Tambah' }} Rate</h2></x-slot>
    <div class="p-6">
        @if ($errors->any())
            <div class="mb-4 rounded bg-red-50 p-4 text-red-700">{{ implode(', ', $errors->all()) }}</div>
        @endif
        <form method="POST" action="{{ $rate->exists ? route('admin.rates.update', $rate) : route('admin.rates.store') }}" class="max-w-xl rounded bg-white p-6 shadow">
            @csrf
            @if($rate->exists) @method('PUT') @endif
            <label class="block">Provider<input name="provider" value="{{ old('provider', $rate->provider) }}" class="mt-1 w-full rounded border p-2"></label>
            <label class="mt-4 block">Rate<input name="rate" type="number" step="0.01" value="{{ old('rate', $rate->rate) }}" class="mt-1 w-full rounded border p-2"></label>
            <label class="mt-4 block">Minimal<input name="min_amount" type="number" value="{{ old('min_amount', $rate->min_amount ?? 50000) }}" class="mt-1 w-full rounded border p-2"></label>
            <label class="mt-4 block">Maksimal<input name="max_amount" type="number" value="{{ old('max_amount', $rate->max_amount ?? 1000000) }}" class="mt-1 w-full rounded border p-2"></label>
            <label class="mt-4 block">Urutan<input name="sort_order" type="number" value="{{ old('sort_order', $rate->sort_order ?? 0) }}" class="mt-1 w-full rounded border p-2"></label>
            <label class="mt-4 flex gap-2"><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $rate->is_active ?? true))> Aktif</label>
            <button class="mt-6 rounded bg-blue-600 px-4 py-2 text-white">Simpan</button>
        </form>
    </div>
</x-app-layout>
