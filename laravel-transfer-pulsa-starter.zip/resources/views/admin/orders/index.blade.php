<x-app-layout>
    <x-slot name="header"><h2 class="font-semibold text-xl">Daftar Order</h2></x-slot>
    <div class="p-6">
        @if(session('success'))<p class="mb-4 text-green-700">{{ session('success') }}</p>@endif
        <table class="w-full rounded bg-white text-sm shadow">
            <thead><tr class="border-b"><th class="p-3 text-left">Invoice</th><th>Customer</th><th>Provider</th><th>Nominal</th><th>Pencairan</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
                @foreach($orders as $order)
                    <tr class="border-b">
                        <td class="p-3">{{ $order->invoice }}</td>
                        <td>{{ $order->name }}<br>{{ $order->phone }}</td>
                        <td>{{ $order->provider }}<br>Rate {{ $order->rate }}</td>
                        <td>Rp{{ number_format($order->amount,0,',','.') }}</td>
                        <td>{{ $order->payout_method }}<br>Rp{{ number_format($order->payout_amount,0,',','.') }}</td>
                        <td>{{ $order->status }}</td>
                        <td>
                            <form method="POST" action="{{ route('admin.orders.status', $order) }}">
                                @csrf @method('PATCH')
                                <select name="status" class="rounded border">
                                    @foreach(['pending','waiting_pulse','processing','paid','rejected'] as $status)
                                        <option @selected($order->status === $status)>{{ $status }}</option>
                                    @endforeach
                                </select>
                                <button class="rounded bg-slate-800 px-2 py-1 text-white">OK</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="mt-4">{{ $orders->links() }}</div>
    </div>
</x-app-layout>
