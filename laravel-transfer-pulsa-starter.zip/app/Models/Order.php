<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'invoice',
        'name',
        'phone',
        'provider',
        'amount',
        'rate',
        'payout_amount',
        'payout_method',
        'account_name',
        'account_number',
        'note',
        'status',
    ];

    protected $casts = [
        'amount' => 'integer',
        'payout_amount' => 'integer',
        'rate' => 'decimal:2',
    ];

    public static function makeInvoice(): string
    {
        return 'TP-' . now()->format('YmdHis') . '-' . random_int(100, 999);
    }
}
