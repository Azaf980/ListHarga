<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Rate;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    public function create()
    {
        return view('orders.create', [
            'rates' => Rate::where('is_active', true)->orderBy('sort_order')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'string', 'max:30'],
            'provider' => ['required', 'string', 'exists:rates,provider'],
            'amount' => ['required', 'integer', 'min:10000'],
            'payout_method' => ['required', 'string', 'max:50'],
            'account_name' => ['required', 'string', 'max:100'],
            'account_number' => ['required', 'string', 'max:100'],
            'note' => ['nullable', 'string', 'max:1000'],
        ]);

        $rate = Rate::where('provider', $validated['provider'])->where('is_active', true)->firstOrFail();

        if ($validated['amount'] < $rate->min_amount || $validated['amount'] > $rate->max_amount) {
            return back()
                ->withInput()
                ->withErrors(['amount' => 'Nominal harus antara Rp'.number_format($rate->min_amount,0,',','.').' sampai Rp'.number_format($rate->max_amount,0,',','.')]);
        }

        $payoutAmount = (int) floor($validated['amount'] * (float) $rate->rate);

        $order = Order::create([
            ...$validated,
            'invoice' => Order::makeInvoice(),
            'rate' => $rate->rate,
            'payout_amount' => $payoutAmount,
            'status' => 'pending',
        ]);

        $adminPhone = config('services.admin_whatsapp', '6281234567890');
        $message = "Halo Admin, saya ingin convert pulsa.\n\n"
            ."Invoice: {$order->invoice}\n"
            ."Nama: {$order->name}\n"
            ."No HP: {$order->phone}\n"
            ."Provider: {$order->provider}\n"
            ."Nominal: Rp".number_format($order->amount, 0, ',', '.')."\n"
            ."Rate: {$order->rate}\n"
            ."Estimasi diterima: Rp".number_format($order->payout_amount, 0, ',', '.')."\n"
            ."Metode: {$order->payout_method}\n"
            ."A/N: {$order->account_name}\n"
            ."Nomor/Rekening: {$order->account_number}";

        return redirect()->away('https://wa.me/'.$adminPhone.'?text='.rawurlencode($message));
    }
}
