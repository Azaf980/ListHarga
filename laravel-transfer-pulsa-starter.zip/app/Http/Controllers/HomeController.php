<?php

namespace App\Http\Controllers;

use App\Models\Rate;

class HomeController extends Controller
{
    public function index()
    {
        $rates = Rate::where('is_active', true)->orderBy('sort_order')->get();

        return view('home', [
            'rates' => $rates,
            'whatsapp' => config('services.admin_whatsapp', '6281234567890'),
        ]);
    }
}
