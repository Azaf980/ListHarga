<?php

namespace Database\Seeders;

use App\Models\Rate;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@example.com'],
            ['name' => 'Admin', 'password' => Hash::make('password')]
        );

        $rates = [
            ['provider' => 'Telkomsel', 'rate' => 0.78],
            ['provider' => 'XL', 'rate' => 0.84],
            ['provider' => 'Axis', 'rate' => 0.83],
            ['provider' => 'Indosat', 'rate' => 0.82],
            ['provider' => 'Tri', 'rate' => 0.80],
            ['provider' => 'Smartfren', 'rate' => 0.76],
        ];

        foreach ($rates as $i => $rate) {
            Rate::updateOrCreate(
                ['provider' => $rate['provider']],
                $rate + ['min_amount' => 50000, 'max_amount' => 1000000, 'is_active' => true, 'sort_order' => $i]
            );
        }
    }
}
