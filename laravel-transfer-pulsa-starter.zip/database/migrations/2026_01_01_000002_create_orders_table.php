<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('invoice')->unique();
            $table->string('name');
            $table->string('phone');
            $table->string('provider');
            $table->unsignedInteger('amount');
            $table->decimal('rate', 4, 2);
            $table->unsignedInteger('payout_amount');
            $table->string('payout_method');
            $table->string('account_name');
            $table->string('account_number');
            $table->text('note')->nullable();
            $table->enum('status', ['pending', 'waiting_pulse', 'processing', 'paid', 'rejected'])->default('pending');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
