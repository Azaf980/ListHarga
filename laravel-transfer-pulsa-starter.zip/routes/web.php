<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\RateController;
use App\Http\Controllers\Admin\OrderAdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/convert-pulsa', [OrderController::class, 'create'])->name('orders.create');
Route::post('/convert-pulsa', [OrderController::class, 'store'])->name('orders.store');

Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', DashboardController::class)->name('dashboard');
    Route::resource('rates', RateController::class);
    Route::get('orders', [OrderAdminController::class, 'index'])->name('orders.index');
    Route::patch('orders/{order}/status', [OrderAdminController::class, 'updateStatus'])->name('orders.status');
});

require __DIR__.'/auth.php';
